// The id of stores will be unique
const stores = [
    { id: 1, city: 'Austin', state: 'TX', zipCode: 78703 },
    { id: 2, city: 'New Orleans', state: 'LA', zipCode: 70114 },
    { id: 3, city: 'San Francisco', state: 'CA', zipCode: 94107 }
];

export default stores;