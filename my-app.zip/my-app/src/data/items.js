

// id values will be unique
const items = [
    { id: '0a3451', name: 'Milk', price: 2.55 },
    { id: '0a3672', name: 'Pizza', price: 8.99 },
    { id: '82345', name: 'Mango', price: 4.00 },
];

export default items;